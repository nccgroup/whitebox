#pragma once

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>


//
// Taken from IOCTLCMD.h from RegSrc.zip
// Commands that the GUI can send the device driver
// 
#define IOCTL_REGMON_HOOK      (ULONG) CTL_CODE( FILE_DEVICE_REGMON, 0x00, METHOD_BUFFERED, FILE_WRITE_ACCESS )
#define IOCTL_REGMON_UNHOOK    (ULONG) CTL_CODE( FILE_DEVICE_REGMON, 0x01, METHOD_BUFFERED, FILE_WRITE_ACCESS )
#define IOCTL_REGMON_ZEROSTATS (ULONG) CTL_CODE( FILE_DEVICE_REGMON, 0x02, METHOD_BUFFERED, FILE_WRITE_ACCESS )
#define IOCTL_REGMON_GETSTATS  (ULONG) CTL_CODE( FILE_DEVICE_REGMON, 0x03, METHOD_NEITHER, FILE_WRITE_ACCESS )
#define IOCTL_REGMON_SETFILTER (ULONG) CTL_CODE( FILE_DEVICE_REGMON, 0x04, METHOD_BUFFERED, FILE_WRITE_ACCESS )
#define IOCTL_REGMON_VERSION   (ULONG) CTL_CODE( FILE_DEVICE_REGMON, 0x05, METHOD_BUFFERED, FILE_WRITE_ACCESS )

// Taken from REGMON.h from RegSrc.zip
#define	SYS_FILE			_T("REGSYS701.SYS")
// This should be changed for the version of the driver you're using - old one was REGMON
#define	SYS_NAME			_T("REGMON701")

// Taken from IOCTLCMD.h from RegSrc.zip
#define PAGE_SIZE 0x1000  // 4K
#define LOGBUFSIZE  	(PAGE_SIZE*16 - 3*sizeof(ULONG))
#define FILE_DEVICE_REGMON      0x00008305

// Taken from IOCTLCMD.h from RegSrc.zip
// Length of a filter definition string
// Update: This is the *new* size for the newer ver
//         of the driver - old size was 200
#define MAXFILTERLEN   1024

// Taken from IOCTLCMD.h from RegSrc.zip
// Filter definition
typedef struct {
        CHAR   includefilter[MAXFILTERLEN];
        CHAR    excludefilter[MAXFILTERLEN];
        BOOLEAN  logsuccess;
        BOOLEAN  logerror;
        BOOLEAN  logreads;
        BOOLEAN  logwrites;
		BOOLEAN  logaux;
} FILTER, *PFILTER;

// Taken from
// http://www.xfocus.net/articles/200210/456.html
typedef struct _LSA_UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PVOID  Buffer;
} LSA_UNICODE_STRING, *PLSA_UNICODE_STRING; 

typedef LSA_UNICODE_STRING UNICODE_STRING, *PUNICODE_STRING;

typedef struct _ANSI_STRING {
  USHORT Length;
  USHORT MaximumLength;
  PCHAR Buffer;
}ANSI_STRING,*PANSI_STRING;