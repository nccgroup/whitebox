//
// Author	: Ollie Whitehouse
// Title	: Example registry change notification - via FileMon driver
// Notes	: Some portions are Copyright (c) 1996 - 2000 Mark Russinovich and Bryce Cogswell
// Sources	: http://msdn2.microsoft.com/en-us/library/ms724892.aspx
//            http://www.xfocus.net/articles/200210/456.html
//            FileSrc.zip
//

#include "stdafx.h"

// Taken from RegSrc.zip
HANDLE SysHandle = INVALID_HANDLE_VALUE;
TCHAR	strSystemRoot[ MAX_PATH ];
TCHAR   strDeviceDir[MAX_PATH];
char	Stats[ LOGBUFSIZE];

// Taken from http://www.xfocus.net/articles/200210/456.html
typedef DWORD (CALLBACK* NTLOADDRIVER)(PVOID);
NTLOADDRIVER NtLoadDriver;
typedef DWORD (CALLBACK* RTLFREEANSISTRING)(PVOID);
RTLFREEANSISTRING RtlFreeAnsiString;
typedef DWORD (CALLBACK* RTLUNICODESTRINGTOANSISTRING)(PANSI_STRING, PUNICODE_STRING,DWORD);
RTLUNICODESTRINGTOANSISTRING RtlUnicodeStringToAnsiString;
typedef DWORD (CALLBACK* RTLINITANSISTRING)(PVOID, PVOID);
RTLINITANSISTRING RtlInitAnsiString;
typedef DWORD (CALLBACK* RTLANSISTRINGTOUNICODESTRING)(PVOID, PVOID,DWORD);
RTLANSISTRINGTOUNICODESTRING RtlAnsiStringToUnicodeString;
typedef DWORD (CALLBACK* RTLFREEUNICODESTRING)(PVOID);
RTLFREEUNICODESTRING RtlFreeUnicodeString;

//
// Function	: PrintHex
// Role		: Prints out pretty style the data
// Notes	: 
//
void PrintHex (DWORD dwOffset, LPBYTE pBytes, DWORD dwLen,DWORD dwPrettyOffset)
{
    TCHAR *szOutStr;
    DWORD dwStartOffset, i, j;
	
	szOutStr = (TCHAR *)LocalAlloc(LMEM_FIXED,dwLen*6);
	
    for (dwStartOffset = 0; dwStartOffset < dwLen; dwStartOffset += 16) {
		wsprintf (szOutStr, TEXT(" "));
        i = (DWORD)_tcslen(szOutStr);

        // Print them out in HEX
        for (j=0; j < 16; j++) {
            if ((dwStartOffset + j) < dwLen) {
#define HEX2CHAR(x) (((x) < 0x0a) ? (x) + '0' : ((x)-0xa) + 'A')
                szOutStr[i++] = HEX2CHAR(pBytes[dwStartOffset+j]>>4);
                szOutStr[i++] = HEX2CHAR(pBytes[dwStartOffset+j]&0x0F);
            } else {
                szOutStr[i++] = TEXT(' ');
                szOutStr[i++] = TEXT(' ');
            }
            szOutStr[i++] = TEXT(' ');
            if (7 == j) {
                szOutStr[i++] = TEXT('-');
                szOutStr[i++] = TEXT(' ');
            }

        }

        // A little space
        for (j=0; j < 5; j++) {
            szOutStr[i++] = TEXT(' ');
        }
        szOutStr[i++] = TEXT(':');

        for (j=0; j < 16; j++) {
            if ((dwStartOffset + j) < dwLen) {
                if ((pBytes[dwStartOffset+j] < ' ') || (pBytes[dwStartOffset+j] >= 0x7f)) {
                    szOutStr[i++] = TEXT('.');
                } else {
                    szOutStr[i++] = pBytes[dwStartOffset+j];
                }
            } else {
                szOutStr[i++] = TEXT(' ');
            }
        }
        szOutStr[i++] = TEXT(':');
        szOutStr[i++] = TEXT('\r');
        szOutStr[i++] = TEXT('\n');
        szOutStr[i++] = TEXT('\0');
        
		// Some output
		fwprintf(stdout, TEXT("%s"),szOutStr);
    }

	LocalFree(szOutStr);

}

//
// Function	: PrintOutput
// Role		: Takes the buffer we recieve from the driver and prints it out nicley
// Notes	: This is not perfect but good enough for the demo...
//
void PrintOutput(LPBYTE pBytes, DWORD dwLen){

	DWORD dwNULLS=0;
	DWORD dwCount=0;


	for(dwCount=0;dwCount<dwLen;dwCount++){

		if(pBytes[dwCount]==0xC7 && pBytes[dwCount+1]==0x01 )
		{
			dwCount++;
			dwCount++;
			while(pBytes[dwCount]!= 0x00){
				
				if(pBytes[dwCount]== 0x09)
					fprintf(stdout, ",");
				else
					fprintf(stdout, "%c",pBytes[dwCount]);

				dwCount++;
			}
			fprintf(stdout,"\n");
		}

	}

}

//
// Function	: SetPrivilege
// Role		: Enables a particular windows priv for the process
// Notes	: 
//
BOOL SetPrivilege(HANDLE hProcess, TCHAR *strPriv)
{
	LUID luid ;
	TOKEN_PRIVILEGES privs ;
	HANDLE hToken = NULL ;
	DWORD dwBufLen = 0 ;
	char buf[1024] ;
	
	ZeroMemory( &luid,sizeof(luid) ) ;
	
	if(! LookupPrivilegeValue( NULL, strPriv, &luid ))
		return false ;
	
	privs.PrivilegeCount = 1 ;
	privs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED ;
	memcpy( &privs.Privileges[0].Luid, &luid, sizeof(privs.Privileges[0].Luid )
		) ;
	
	
	if( ! OpenProcessToken( hProcess, TOKEN_ALL_ACCESS,&hToken))
		return false ;
	
	if( !AdjustTokenPrivileges( hToken, FALSE, &privs,
		sizeof(buf),(PTOKEN_PRIVILEGES)buf, &dwBufLen ) )
		return false ;

	CloseHandle(hProcess);
	CloseHandle(hToken);
	
	return true ;
}

//
// Function	: RegHandleDev
// Role		: Registers the driver and loads it
// Notes	: 
//
int RegHandelDev(TCHAR * exename)
{
    TCHAR subkey[MAX_PATH];
	char foo[MAX_PATH];
    LSA_UNICODE_STRING buf1;
    LSA_UNICODE_STRING buf2;
    int buflen;
    HKEY hkResult;
    TCHAR Data[4];
    DWORD isok;
	HMODULE hNtdll = NULL;

	_tprintf( TEXT("[d] RegHandleDev()....\n"));

	// Get some function pointers we need
	hNtdll = LoadLibrary( L"ntdll.dll" ); 
	NtLoadDriver = (NTLOADDRIVER) GetProcAddress(    hNtdll,    "NtLoadDriver");
	RtlAnsiStringToUnicodeString = (RTLANSISTRINGTOUNICODESTRING) GetProcAddress(    hNtdll,    "RtlAnsiStringToUnicodeString");
    RtlFreeUnicodeString = (RTLFREEUNICODESTRING) GetProcAddress(    hNtdll,    "RtlFreeUnicodeString");
	
	// Create the base key and set some fluff
	buflen = swprintf(subkey,L"System\\CurrentControlSet\\Services\\%s",exename);
    subkey[buflen]=0;
    isok = RegCreateKey(HKEY_LOCAL_MACHINE,subkey,&hkResult);
	if(isok!=ERROR_SUCCESS){
        _tprintf( TEXT("[!] RegCreateKey failed - %d\n"),GetLastError());
		return false;
	}
	Data[0]=1;
    Data[1]=0;
    Data[2]=0;
    Data[3]=0;
    isok=RegSetValueEx(hkResult,L"Type",0,REG_DWORD,(const unsigned char *)Data,4);
    isok=RegSetValueEx(hkResult,L"ErrorControl",0,REG_DWORD,(const unsigned char *)Data,4);
    isok=RegSetValueEx(hkResult,L"Start",0,REG_DWORD,(const unsigned char *)Data,4);
	
	//isok=RegSetValueEx(hkResult,L"Group",0,REG_SZ,"System Bus Extender",19);
	//isok=RegSetValueEx(hkResult,L"ImagePath",0,REG_SZ,"System32\\Drivers\\REGSYS701.SYS",30);


	// Now set the image path to the driver DLL
    buflen = wsprintf(strDeviceDir,L"System32\\Drivers\\%s",SYS_FILE);
    buflen = wsprintf(subkey,L"%s",strDeviceDir);
	_tprintf( TEXT("[d] Location - %s\n"),subkey);
    subkey[buflen*2]=0;
    isok=RegSetValueExW(hkResult,L"ImagePath",0,1,(const BYTE *)subkey,buflen*2);
    
	// Now set the type
    buflen = wsprintf(subkey,L"System Bus Extender");
	_tprintf( TEXT("[d] Driver Type - %s\n"),subkey);
    subkey[buflen*2]=0;
    isok=RegSetValueExW(hkResult,L"Group",0,1,(const BYTE *)subkey,buflen*2);
	
	//
	RegCloseKey(hkResult);

	// Now prepare the string to load it
	// This is shitty hard coded but good enough for our demo
    buflen = sprintf(foo,"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\FILEMON701");
    foo[buflen]=0;
    buf2.Buffer = (PVOID)foo;
    buf2.Length = buflen;
    RtlAnsiStringToUnicodeString(&buf1,&buf2,1);

	// Load the driver
	_tprintf( TEXT("[d] Loading - %s\n"),exename);
    isok = NtLoadDriver(&buf1);
    RtlFreeUnicodeString(&buf1);
    
	buflen=swprintf(subkey,L"%s%s\\Enum","System\\CurrentControlSet\\Services\\",exename);
    subkey[buflen]=0;

	// Open the device
    SysHandle = CreateFile(subkey,GENERIC_READ|GENERIC_WRITE,NULL,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(SysHandle==INVALID_HANDLE_VALUE)
    {
		buflen=swprintf(subkey,L"\\\\.\\Global\\%s",exename);
		_tprintf( TEXT("[d] Opening - %s\n"),subkey);
        subkey[buflen]=0;
        SysHandle = CreateFile(subkey,GENERIC_READ|GENERIC_WRITE,NULL,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if(SysHandle==INVALID_HANDLE_VALUE){
             _tprintf( TEXT("[!] Failed to open device - %d\n"),GetLastError());
			return false;
		}
    }
    return true;
}

//
// Function	: CleanUp
// Role		: Cleanups after ourselves
// Notes	: 
//
void CleanUp(){
	DWORD dwFoo=0;

	// Turn off the hooks
	if ( ! DeviceIoControl(	SysHandle, IOCTL_FILEMON_STOPFILTER,
			NULL, 0, NULL, 0, &dwFoo, NULL ) ) {
		_tprintf( TEXT("[!] Couldn't get FileMon driver to turn off hooks!\n"));
		ExitProcess(1);
	} else {
		_tprintf( TEXT("[i] FileMon has turned off filtering\n"));
	}
}

//
// Function	: CtrlHandler
// Role		: Handles ctrl-c and the like
// Notes	: 
//
BOOL CtrlHandler( DWORD fdwCtrlType ) 
{ 
  switch( fdwCtrlType ) 
  { 
    // Handle the CTRL-C signal. 
    case CTRL_C_EVENT: 
      CleanUp();
      ExitProcess(1);
	  break;
 
    // CTRL-CLOSE: confirm that the user wants to exit. 
    case CTRL_CLOSE_EVENT: 
      CleanUp();
      ExitProcess(1);
	  break;
 
    // Pass other signals to the next handler. 
    case CTRL_BREAK_EVENT: 
      CleanUp();
      ExitProcess(1);
	  break;
 
    case CTRL_LOGOFF_EVENT: 
      CleanUp();
      ExitProcess(1);
	  break;
 
    case CTRL_SHUTDOWN_EVENT: 
      CleanUp();
      ExitProcess(1);
	  break;
 
    default: 
      return FALSE; 
  } 
} 


//
// Function	: _tmain
// Role		: Application entry point
// Notes	: 
//
int _tmain(int argc, _TCHAR* argv[])
{
	DWORD dwError=0,dwVersionNumber=0,dwLen=0,dwFoo=0;
	static	TCHAR strDriverPath[ MAX_PATH ];
	TCHAR   strPath[ MAX_PATH ];
	FILTER	FilterDefinition;
	DWORD	CurDriveSet;
	DWORD	dwCrapOla=0; // a dummy var for when we turn the hooks on

	_tprintf( TEXT("[i] --------------------------------------------\n"));
	_tprintf( TEXT("[i] Auhtor : Ollie Whitehouse\n"));
	_tprintf( TEXT("[i] --------------------------------------------\n"));

	if ( SetPrivilege(GetCurrentProcess(),L"SeLoadDriverPrivilege")){
		_tprintf( TEXT("[i] Privilege obtained - SeLoadDriverPrivilege\n"));
	} else{
		_tprintf( TEXT("[!] Failed to obtain privileges - SeLoadDriverPrivilege\n"));
		return 1;
	}

	if ( SetPrivilege(GetCurrentProcess(),L"SeDebugPrivilege")){
		_tprintf( TEXT("[i] Privilege obtained - SeDebugPrivilege\n"));
	} else{
		_tprintf( TEXT("[!] Failed to obtain privileges - SeDebugPrivilege\n"));
		return 1;
	}


	// Copy the driver to the correct location
	GetCurrentDirectory( sizeof strPath, strPath );
	swprintf( strPath+lstrlen(strPath), _T("\\%s"), SYS_FILE );
	if( !GetEnvironmentVariable( L"SYSTEMROOT", strSystemRoot, sizeof(strSystemRoot))) {
	
	}
	swprintf( strDriverPath, _T("%s\\system32\\drivers\\%s"), strSystemRoot, SYS_FILE );
	if( !CopyFile( strPath, strDriverPath, FALSE )) {
		_tprintf( TEXT("[!] Couldn't copy driver to system root!\n"));
		ExitProcess(1);
	} 


	// Setup and load the driver
	if(RegHandelDev(L"FILEMON701")==false){
		_tprintf( TEXT("[!] Loading of driver failed...\n"));
		ExitProcess(1);
	}

	// Print out the version number of the driver
	if ( ! DeviceIoControl(	SysHandle, IOCTL_FILEMON_VERSION, 
		NULL, 0, &dwVersionNumber, sizeof(DWORD), &dwFoo, NULL )){
		_tprintf( TEXT("[!] Couldn't get FileMon driver version!\n"));
		ExitProcess(1);
	} else {
		_tprintf( TEXT("[i] FileMon Driver Version: %d\n"), dwVersionNumber);
	}

	
	// Set which drives to monitor
	DWORD dwMaxDriveSet=0;
	dwMaxDriveSet = GetLogicalDrives();
	CurDriveSet=dwMaxDriveSet;
	if ( ! DeviceIoControl(	SysHandle, IOCTL_FILEMON_SETDRIVES,
							&CurDriveSet, sizeof CurDriveSet,
							&CurDriveSet, sizeof CurDriveSet,
							&dwFoo, NULL ) ){
		_tprintf( TEXT("[!] Couldn't set FileMon drvies!\n"));
		ExitProcess(1);
	} else {
		_tprintf( TEXT("[i] FileMon drives to minitor set - %d\n"),dwFoo);
	}

	
	// Set the filters
	memset(&FilterDefinition,0x00,sizeof(FILTER));
	strcpy( FilterDefinition.excludefilter,"EXPLORER.EXE");
	strcpy( FilterDefinition.includefilter, "*");
	FilterDefinition.logsucess=TRUE;
	FilterDefinition.logerrors=TRUE;
	FilterDefinition.logreads=TRUE;
	FilterDefinition.logwrites=TRUE;
	FilterDefinition.logopens=TRUE;
	if ( ! DeviceIoControl(	SysHandle, IOCTL_FILEMON_SETFILTER,
			(PVOID) &FilterDefinition, sizeof(FILTER), 
			NULL, 0, &dwFoo, NULL ) )	{
		_tprintf( TEXT("[!] Couldn't set FileMon filters\n"));
		ExitProcess(1);
	} else {
		_tprintf( TEXT("[i] FileMon filters set - %d - %d\n"),dwFoo,sizeof(FilterDefinition));
	}


	// Tell driver to start filtering
	if ( ! DeviceIoControl(	SysHandle, IOCTL_FILEMON_STARTFILTER,
			NULL, 0, NULL, 0, &dwFoo, NULL ) )	{
		_tprintf( TEXT("[!] Couldn't get FileMon to start filtering!"));
		ExitProcess(1);
	} else {
		_tprintf( TEXT("[i] FileMon now filtering - %d \n"),dwFoo);
	}

	// Install our control handler
	if( SetConsoleCtrlHandler( (PHANDLER_ROUTINE) CtrlHandler, TRUE ) ) 
	{
		_tprintf( TEXT("[i] Control handler installed\n"));
	}

	// Now loop
	while(1){
		// Have driver fill stats buffer
		if (! DeviceIoControl(	SysHandle, IOCTL_FILEMON_GETSTATS,
							NULL, 0, &Stats, sizeof Stats,
							&dwLen, NULL ) ) 
		{
			// Unload the driver and exit
			ExitProcess(1);
		} else {
			if(dwLen>0){
				//_tprintf( TEXT("[i] We got data!\n"));
				//PrintHex(0,(LPBYTE)Stats,dwLen,0);
				PrintOutput((LPBYTE)Stats,dwLen);
			}
		}

		// Have a little nap
		Sleep(500);
	}

	return 0;
}
